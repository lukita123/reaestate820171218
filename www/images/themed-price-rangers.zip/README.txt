A Pen created at CodePen.io. You can find this one at https://codepen.io/ScottMarshall/pen/kfrwz.

 hey guys here are some sleek price rangers I developed for my contact form there are fully supported in chrome working on prefixes :)